// Server-only Razorpay helpers. Never import from client code.
import { createHmac, timingSafeEqual } from "node:crypto";

export type RazorpayCredentials = { keyId: string; keySecret: string };

export function getRazorpayCredentials(): RazorpayCredentials {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) {
    throw new Error(
      "Razorpay is not configured. Missing RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET.",
    );
  }
  return { keyId, keySecret };
}

export type RazorpayOrder = {
  id: string;
  amount: number;
  currency: string;
  status: string;
};

export async function createRazorpayOrder(input: {
  amountPaise: number;
  receipt: string;
  notes?: Record<string, string>;
}): Promise<RazorpayOrder> {
  const { keyId, keySecret } = getRazorpayCredentials();
  const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");

  const response = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount: input.amountPaise,
      currency: "INR",
      receipt: input.receipt,
      notes: input.notes ?? {},
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    console.error(`Razorpay order creation failed [${response.status}]: ${body}`);
    throw new Error("Could not start the payment. Please try again.");
  }

  return (await response.json()) as RazorpayOrder;
}

export function verifyRazorpaySignature(input: {
  orderId: string;
  paymentId: string;
  signature: string;
}): boolean {
  const { keySecret } = getRazorpayCredentials();
  const expected = createHmac("sha256", keySecret)
    .update(`${input.orderId}|${input.paymentId}`)
    .digest("hex");
  const given = Buffer.from(input.signature);
  const exp = Buffer.from(expected);
  return given.length === exp.length && timingSafeEqual(given, exp);
}
