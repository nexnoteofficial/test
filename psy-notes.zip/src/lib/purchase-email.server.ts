// Server-only purchase confirmation email.
// Sending goes through Lovable's managed email system, which requires a
// verified sender domain for this project. Until that is configured, this
// logs and returns false so a successful payment is never lost.
import { DOWNLOAD_URL } from "./orders.server";

export async function sendPurchaseEmail(input: {
  name: string;
  email: string;
  downloadToken: string;
}): Promise<boolean> {
  const downloadLink = `${process.env.APP_BASE_URL ?? ""}/download?token=${input.downloadToken}`;
  const fileUrl = process.env.DOWNLOAD_FILE_URL || DOWNLOAD_URL;

  console.warn(
    `[email] Purchase confirmation pending sender-domain setup — ${input.email} (${input.name}): ${downloadLink} / ${fileUrl}`,
  );
  return false;
}
