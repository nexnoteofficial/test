// Server-only order catalogue + persistence helpers.
export const BASE_PRICE = 149;

export const ADDON_CATALOG: Record<string, { title: string; price: number }> = {
  casestudies: { title: "100+ Psychology Case Studies (PDF)", price: 99 },
  mcq: { title: "5,000 MCQ Question Bank + Answer Keys", price: 79 },
  mastery: { title: "Lifetime Updates + Career Mastery Kit", price: 129 },
};

export type PricedAddon = { id: string; title: string; price: number };

export function priceOrder(addonIds: string[]): {
  addons: PricedAddon[];
  totalRupees: number;
  amountPaise: number;
} {
  const unique = Array.from(new Set(addonIds)).filter((id) => id in ADDON_CATALOG);
  const addons = unique.map((id) => ({ id, ...ADDON_CATALOG[id] }));
  const totalRupees = BASE_PRICE + addons.reduce((sum, a) => sum + a.price, 0);
  return { addons, totalRupees, amountPaise: totalRupees * 100 };
}

export const DOWNLOAD_URL =
  "https://cubecrown.com/psychologynotescheckout?fid=103245&ffid=22167&id=118064";

// ---------------------------------------------------------------------------
// 👇 PUT YOUR OWN DOWNLOAD FILE LINKS HERE
// Paste a direct file URL (Google Drive "anyone with link", Dropbox ?dl=1,
// Cloud storage public URL, etc.) for the main bundle and each add-on.
// The keys must match the add-on ids used on the checkout page.
// ---------------------------------------------------------------------------
export const DOWNLOAD_FILES: Record<string, { label: string; url: string }> = {
  base: {
    label: "Psychology Notes Bundle (PDF)",
    url: process.env.DOWNLOAD_FILE_URL || DOWNLOAD_URL,
  },
  casestudies: {
    label: "100+ Psychology Case Studies (PDF)",
    url: DOWNLOAD_URL,
  },
  mcq: {
    label: "5,000 MCQ Question Bank + Answer Keys (PDF)",
    url: DOWNLOAD_URL,
  },
  mastery: {
    label: "Lifetime Updates + Career Mastery Kit",
    url: DOWNLOAD_URL,
  },
};
