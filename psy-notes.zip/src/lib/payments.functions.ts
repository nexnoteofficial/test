import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const createOrderSchema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().min(6).max(20),
  addons: z.array(z.string().max(40)).max(10).default([]),
});

const verifySchema = z.object({
  razorpay_order_id: z.string().min(1).max(120),
  razorpay_payment_id: z.string().min(1).max(120),
  razorpay_signature: z.string().min(1).max(256),
});

export const getRazorpayKeyId = createServerFn({ method: "GET" }).handler(async () => {
  const keyId = process.env.RAZORPAY_KEY_ID;
  return { keyId: keyId ?? null };
});

export const createPaymentOrder = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => createOrderSchema.parse(data))
  .handler(async ({ data }) => {
    const { priceOrder } = await import("@/lib/orders.server");
    const { createRazorpayOrder } = await import("@/lib/razorpay.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { addons, amountPaise, totalRupees } = priceOrder(data.addons);
    const receipt = `psy_${Date.now().toString(36)}`;

    const order = await createRazorpayOrder({
      amountPaise,
      receipt,
      notes: { email: data.email, name: data.name },
    });

    const { error } = await supabaseAdmin.from("orders").insert({
      razorpay_order_id: order.id,
      customer_name: data.name,
      customer_email: data.email,
      customer_phone: data.phone,
      amount_paise: amountPaise,
      currency: order.currency,
      addons,
      status: "created",
    });
    if (error) {
      console.error("Failed to save order", error);
      throw new Error("Could not start the payment. Please try again.");
    }

    return {
      orderId: order.id,
      amountPaise,
      totalRupees,
      currency: order.currency,
      keyId: process.env.RAZORPAY_KEY_ID!,
      customer: { name: data.name, email: data.email, phone: data.phone },
    };
  });

export const verifyPayment = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => verifySchema.parse(data))
  .handler(async ({ data }) => {
    const { verifyRazorpaySignature } = await import("@/lib/razorpay.server");
    const { sendPurchaseEmail } = await import("@/lib/purchase-email.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const valid = verifyRazorpaySignature({
      orderId: data.razorpay_order_id,
      paymentId: data.razorpay_payment_id,
      signature: data.razorpay_signature,
    });

    if (!valid) {
      await supabaseAdmin
        .from("orders")
        .update({ status: "failed", updated_at: new Date().toISOString() })
        .eq("razorpay_order_id", data.razorpay_order_id);
      throw new Error("Payment verification failed. You have not been charged twice — contact support.");
    }

    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .update({
        razorpay_payment_id: data.razorpay_payment_id,
        razorpay_signature: data.razorpay_signature,
        status: "paid",
        updated_at: new Date().toISOString(),
      })
      .eq("razorpay_order_id", data.razorpay_order_id)
      .select("id, customer_name, customer_email, download_token, email_sent")
      .single();

    if (error || !order) {
      console.error("Failed to mark order paid", error);
      throw new Error("Payment captured but the order could not be saved. Contact support.");
    }

    if (!order.email_sent) {
      const sent = await sendPurchaseEmail({
        name: order.customer_name,
        email: order.customer_email,
        downloadToken: order.download_token,
      });
      if (sent) {
        await supabaseAdmin.from("orders").update({ email_sent: true }).eq("id", order.id);
      }
    }

    return { downloadToken: order.download_token as string };
  });

export const getOrderByToken = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => z.object({ token: z.string().uuid() }).parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { DOWNLOAD_FILES } = await import("@/lib/orders.server");

    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("customer_name, customer_email, status, amount_paise, addons")
      .eq("download_token", data.token)
      .eq("status", "paid")
      .maybeSingle();

    if (!order) return { found: false as const };

    const addons = (order.addons ?? []) as { id: string; title: string; price: number }[];
    const files = [
      DOWNLOAD_FILES.base,
      ...addons.map((a) => DOWNLOAD_FILES[a.id]).filter(Boolean),
    ];

    return {
      found: true as const,
      name: order.customer_name,
      email: order.customer_email,
      totalRupees: order.amount_paise / 100,
      addons,
      files,
      downloadUrl: DOWNLOAD_FILES.base.url,
    };
  });
