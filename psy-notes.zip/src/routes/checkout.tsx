import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import bundleImage from "@/assets/psychology-bundle.png";
import { createPaymentOrder, verifyPayment } from "@/lib/payments.functions";

declare global {
  interface Window {
    Razorpay?: new (options: Record<string, unknown>) => { open: () => void };
  }
}

function loadRazorpayScript(): Promise<boolean> {
  if (typeof window === "undefined") return Promise.resolve(false);
  if (window.Razorpay) return Promise.resolve(true);
  return new Promise((resolve) => {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}


export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Secure Checkout — Psychology Notes Bundle ₹149" },
      {
        name: "description",
        content:
          "Complete your secure order for the Psychology Notes bundle. Instant PDF download by email for ₹149 instead of ₹2,499.",
      },
      { property: "og:title", content: "Secure Checkout — Psychology Notes Bundle" },
      {
        property: "og:description",
        content: "One-time special offer. Instant access after checkout for ₹149.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Checkout,
});


const bullets = [
  "Limited Time: 90% OFF",
  "Beginner to Advanced Learning",
  "Easy Notes + Visual Diagrams",
  "Updated & Practical Content",
  "Download Instantly After Purchase",
];

function Field({
  label,
  ...props
}: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold">{label}</span>
      <input
        {...props}
        className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-gold"
      />
    </label>
  );
}

const upsells = [
  {
    id: "casestudies",
    emoji: "🧠",
    title: "100+ Psychology Case Studies (PDF)",
    desc: "Real clinical cases with analysis — perfect for exams & interviews.",
    price: 99,
    strike: 999,
    badge: "Most popular",
  },
  {
    id: "mcq",
    emoji: "📝",
    title: "5,000 MCQ Question Bank + Answer Keys",
    desc: "Topic-wise practice sets for UGC NET, CUET & university exams.",
    price: 79,
    strike: 799,
    badge: "",
  },
  {
    id: "mastery",
    emoji: "🎯",
    title: "Lifetime Updates + Career Mastery Kit",
    desc: "All future note updates, CV templates & counselling starter guide.",
    price: 129,
    strike: 1499,
    badge: "Best value",
  },
] as const;

function Checkout() {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const navigate = useNavigate();
  const createOrder = useServerFn(createPaymentOrder);
  const verify = useServerFn(verifyPayment);

  const toggle = (id: string) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const addOns = upsells.filter((u) => selected.includes(u.id));
  const total = 149 + addOns.reduce((sum, u) => sum + u.price, 0);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    const form = new FormData(e.currentTarget);
    const customer = {
      name: String(form.get("name") ?? "").trim(),
      email: String(form.get("email") ?? "").trim(),
      phone: String(form.get("phone") ?? "").trim(),
    };

    try {
      const scriptReady = await loadRazorpayScript();
      if (!scriptReady || !window.Razorpay) {
        throw new Error("Payment gateway could not load. Check your connection and retry.");
      }

      const order = await createOrder({ data: { ...customer, addons: selected } });

      const rzp = new window.Razorpay({
        key: order.keyId,
        amount: order.amountPaise,
        currency: order.currency,
        order_id: order.orderId,
        name: "Psychology Notes",
        description: "Psychology Notes Bundle (PDF)",
        image: bundleImage,
        prefill: {
          name: customer.name,
          email: customer.email,
          contact: customer.phone,
        },
        theme: { color: "#e0b23c" },
        modal: {
          ondismiss: () => {
            setSubmitting(false);
            setError("Payment was cancelled. Your order is still saved — try again.");
          },
        },
        handler: async (response: {
          razorpay_order_id: string;
          razorpay_payment_id: string;
          razorpay_signature: string;
        }) => {
          try {
            const result = await verify({ data: response });
            navigate({ to: "/download", search: { token: result.downloadToken } });
          } catch (err) {
            setSubmitting(false);
            setError(
              err instanceof Error ? err.message : "Payment verification failed.",
            );
          }
        },
      });

      rzp.open();
    } catch (err) {
      setSubmitting(false);
      setError(err instanceof Error ? err.message : "Something went wrong. Please retry.");
    }
  };


  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <div className="bg-gradient-to-r from-primary to-gold py-2 text-center text-xs font-bold uppercase tracking-widest text-primary-foreground">
        🔒 Secure Checkout · 90% OFF ends soon
      </div>

      <div className="mx-auto max-w-5xl px-5 py-10">
        <Link
          to="/"
          className="text-sm font-semibold text-muted-foreground hover:text-gold"
        >
          ← Back to offer
        </Link>

        <div className="mt-6 grid gap-8 lg:grid-cols-[1.1fr_1fr]">
          {/* Offer summary */}
          <div className="rounded-2xl border border-border bg-surface p-6">
            <span className="inline-block rounded-full border border-border bg-surface-2 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-gold">
              One-time special offer
            </span>
            <h1 className="mt-4 font-display text-3xl font-extrabold">Psychology Notes</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Grab it before the price increases.
            </p>

            <img
              src={bundleImage}
              alt="Psychology notes bundle preview"
              width={1200}
              height={912}
              loading="lazy"
              className="mx-auto my-5 w-full max-w-sm"
            />

            <ul className="space-y-2">
              {bullets.map((b) => (
                <li key={b} className="flex items-center gap-2 text-sm">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gold text-xs font-bold text-accent-foreground">
                    ✓
                  </span>
                  {b}
                </li>
              ))}
            </ul>

            <div className="mt-6 rounded-xl border border-border bg-surface-2 p-4 text-center">
              <p className="text-xs font-bold uppercase tracking-widest text-gold">
                🔥 Limited-time launch price
              </p>
              <p className="mt-2">
                <span className="text-lg text-muted-foreground line-through">₹2,499</span>{" "}
                <span className="font-display text-4xl font-extrabold text-gold">₹149</span>
              </p>
            </div>
          </div>

          {/* Order form */}
          <div className="rounded-2xl border border-border bg-surface p-6">
            <h2 className="font-display text-2xl font-bold">Complete Your Secure Order</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Instant access — download in seconds after checkout.
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <Field label="Full name" name="name" placeholder="Your name" required />
              <Field
                label="Email address"
                name="email"
                type="email"
                placeholder="you@email.com"
                required
              />
              <p className="-mt-2 text-xs text-muted-foreground">
                Your PDF bundle is delivered to this email. Please double-check it.
              </p>
              <Field
                label="Phone number"
                name="phone"
                type="tel"
                inputMode="numeric"
                placeholder="10-digit mobile number"
                required
              />

              <div className="rounded-xl border-2 border-dashed border-gold/60 bg-gold/5 p-4">
                <p className="text-xs font-bold uppercase tracking-widest text-gold">
                  ⚡ One-time add-ons — only at this step
                </p>
                <div className="mt-3 space-y-3">
                  {upsells.map((u) => {
                    const on = selected.includes(u.id);
                    return (
                      <label
                        key={u.id}
                        className={`flex cursor-pointer gap-3 rounded-lg border p-3 transition-colors ${
                          on ? "border-gold bg-surface-2" : "border-border bg-surface"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={on}
                          onChange={() => toggle(u.id)}
                          className="mt-1 h-4 w-4 accent-[oklch(0.8_0.15_85)]"
                        />
                        <span className="flex-1">
                          <span className="flex flex-wrap items-center gap-2 text-sm font-bold">
                            <span>{u.emoji} {u.title}</span>
                            {u.badge && (
                              <span className="rounded-full bg-gold px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent-foreground">
                                {u.badge}
                              </span>
                            )}
                          </span>
                          <span className="mt-1 block text-xs text-muted-foreground">
                            {u.desc}
                          </span>
                          <span className="mt-1 block text-sm font-bold text-gold">
                            +₹{u.price}{" "}
                            <span className="text-xs font-normal text-muted-foreground line-through">
                              ₹{u.strike}
                            </span>
                          </span>
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="rounded-xl border border-border bg-surface-2 p-4 text-sm">
                <div className="flex justify-between">
                  <span>Psychology Notes Bundle (PDF)</span>
                  <span className="text-gold">₹149</span>
                </div>
                {addOns.map((u) => (
                  <div key={u.id} className="mt-2 flex justify-between">
                    <span className="pr-2 text-muted-foreground">+ {u.title}</span>
                    <span className="text-gold">₹{u.price}</span>
                  </div>
                ))}
                <div className="mt-2 flex justify-between">
                  <span>Launch discount (90%)</span>
                  <span className="text-gold">−₹2,350</span>
                </div>
                <div className="mt-3 flex justify-between border-t border-border pt-3 font-display text-lg font-bold">
                  <span>Total</span>
                  <span className="text-gold">₹{total}</span>
                </div>
              </div>

              {error && (
                <p className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="glow-gold w-full rounded-xl bg-gradient-to-b from-gold-soft to-gold py-4 font-display text-lg font-extrabold text-accent-foreground transition-transform hover:scale-[1.01] disabled:opacity-70"
              >
                {submitting ? "Opening secure payment…" : `PAY SECURELY · ₹${total}`}
              </button>




              <div className="flex flex-wrap justify-center gap-3 text-xs text-muted-foreground">
                <span>🔒 256-bit secure payment</span>
                <span>📥 Instant delivery</span>
                <span>📧 Email support</span>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
