import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import bundleImage from "@/assets/psychology-bundle.png";
import pdfPage1 from "@/assets/pdf-page-1.jpg";
import pdfPage2 from "@/assets/pdf-page-2.jpg";
import pdfPage3 from "@/assets/pdf-page-3.jpg";
import pdfPage4 from "@/assets/pdf-page-4.jpg";

const pdfSlides = [
  { src: pdfPage1, label: "The Brain: Anatomy & Functions" },
  { src: pdfPage2, label: "Maslow's Hierarchy of Needs" },
  { src: pdfPage3, label: "The CBT Model" },
  { src: pdfPage4, label: "Memory & Learning" },
];

function PdfSlideshow() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setActive((i) => (i + 1) % pdfSlides.length);
    }, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="mx-auto w-full max-w-md">
      <div className="relative aspect-[1024/1330] w-full overflow-hidden rounded-2xl border border-border bg-card shadow-xl">
        {pdfSlides.map((slide, i) => (
          <img
            key={slide.label}
            src={slide.src}
            alt={`Sample page from the psychology notes PDF: ${slide.label}`}
            width={1024}
            height={1330}
            loading="lazy"
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${
              i === active ? "opacity-100" : "opacity-0"
            }`}
          />
        ))}
      </div>
      <div className="mt-4 flex items-center justify-center gap-2">
        {pdfSlides.map((slide, i) => (
          <button
            key={slide.label}
            type="button"
            onClick={() => setActive(i)}
            aria-label={`Show ${slide.label}`}
            className={`h-2 rounded-full transition-all ${
              i === active ? "w-6 bg-gold" : "w-2 bg-border"
            }`}
          />
        ))}
      </div>
      <p className="mt-3 text-center text-sm font-semibold text-muted-foreground">
        {pdfSlides[active].label}
      </p>
    </div>
  );
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Psychology Notes Bundle — Basic to Advanced PDF at ₹149" },
      {
        name: "description",
        content:
          "Complete psychology study notes, basic to advanced. Easy notes, visual diagrams, instant PDF download by email. 90% off — only ₹149 for a limited time.",
      },
      { property: "og:title", content: "Psychology Notes Bundle — Basic to Advanced" },
      {
        property: "og:description",
        content:
          "17+ psychology topics with simplified notes and diagrams. Instant PDF access for ₹149 instead of ₹2,499.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});



const whyNow = [
  { icon: "🔥", text: "Limited time: flat 90% off" },
  { icon: "📖", text: "Beginner to advanced learning path" },
  { icon: "🎯", text: "Easy notes + visual diagrams" },
  { icon: "⚡", text: "Updated & practical content" },
  { icon: "📥", text: "Instant download after purchase" },
  { icon: "🚀", text: "Start today before the price goes up" },
];

const careerBenefits = [
  { icon: "📚", title: "Beginner to advanced", body: "One structured path from first principles to exam-level depth." },
  { icon: "🧠", title: "Everything in one place", body: "No more hunting across ten textbooks and random PDFs." },
  { icon: "🎯", title: "Real subject clarity", body: "Concepts explained in plain language with worked diagrams." },
  { icon: "🚀", title: "Career opportunities", body: "Foundations used in counselling, HR, research and UGC-NET prep." },
  { icon: "⚡", title: "Study smarter", body: "Revision-ready summaries that cut your study time in half." },
  { icon: "📖", title: "Lifetime access", body: "Download once, keep it on every device you own, forever." },
];

const topics = [
  "🧠 Science of Psychology",
  "📚 Modern Approaches",
  "🎯 Fields of Psychology",
  "👨‍⚕️ Psychological Profession",
  "🤝 Social Psychology",
  "🧩 Memory",
  "👁️ Perception",
  "🧬 Biology and Behavior",
  "📖 Learning",
  "🌱 Development",
  "🔥 Motivation",
  "😰 Stress and Emotions",
  "💡 Personality",
  "⚠️ Psychological Disorders",
  "💊 Treatment of Disorders",
  "🧬 Biological Basis of Behaviour",
  "⏳ Development Across Lifespan",
];

const reviews = [
  { name: "Priya Sharma", city: "Delhi", text: "This psychology bundle made complex topics super easy to understand. The diagrams and notes are amazing." },
  { name: "Rahul Verma", city: "Mumbai", text: "Best psychology study material I've purchased online. Beginner to advanced concepts covered perfectly." },
  { name: "Sneha Patel", city: "Ahmedabad", text: "The explanations are very simple and practical. Helped me a lot in understanding psychology concepts." },
  { name: "Aman Kumar", city: "Patna", text: "Excellent content quality. Notes are easy to revise and perfect for students preparing seriously." },
  { name: "Neha Singh", city: "Lucknow", text: "I loved the visual diagrams and structured learning. Much better than confusing textbooks." },
  { name: "Arjun Mehta", city: "Jaipur", text: "This bundle saved me so much time. Everything is organised and easy to study." },
  { name: "Pooja Roy", city: "Kolkata", text: "Very useful for psychology beginners. The language is simple and concepts are explained clearly." },
  { name: "Karan Malhotra", city: "Chandigarh", text: "One of the best psychology bundles available online. Worth much more than the price." },
  { name: "Ritika Jain", city: "Bangalore", text: "Professional quality content with easy explanations. Perfect for learning step by step." },
];

const faqs = [
  {
    q: "What if I enter the wrong email ID or don't get access after payment?",
    a: "Relax. Mail us at support@example.com with your transaction ID and we'll resend your access as soon as possible.",
  },
  { q: "What is the language of the content?", a: "The content is written in simple, easy-to-understand basic English for beginners and students." },
  { q: "Is this bundle suitable for beginners?", a: "Yes. It is designed for complete beginners as well as advanced learners." },
  { q: "Will I get instant access after purchase?", a: "Yes, you receive instant access to all ebooks and materials immediately after successful payment." },
  { q: "Can I access the content on mobile and laptop?", a: "Absolutely. The PDFs work on mobile phones, tablets, laptops and desktops." },
  { q: "Are the notes easy to understand?", a: "Yes, everything is simplified with easy explanations, diagrams and structured learning." },
  { q: "Is this useful for psychology students?", a: "Definitely — it suits psychology students, self-learners and competitive exam preparation." },
  { q: "Do I need prior psychology knowledge?", a: "No prior knowledge is required. It starts from basics and gradually moves to advanced topics." },
];

function BuyButton({ label = "BUY NOW", sub = "Click here to get instant access" }) {
  return (
    <Link
      to="/checkout"
      className="glow-gold inline-flex w-full max-w-md flex-col items-center rounded-xl bg-gradient-to-b from-gold-soft to-gold px-8 py-4 text-accent-foreground transition-transform hover:scale-[1.02] active:scale-100 sm:w-auto"
    >
      <span className="font-display text-lg font-extrabold tracking-wide">{label}</span>
      <span className="text-xs font-semibold opacity-80">{sub}</span>
    </Link>
  );
}

function Countdown() {
  const [left, setLeft] = useState(6 * 3600 + 42 * 60);
  useEffect(() => {
    const t = setInterval(() => setLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);
  const parts = [
    { v: Math.floor(left / 86400), l: "Days" },
    { v: Math.floor((left % 86400) / 3600), l: "Hours" },
    { v: Math.floor((left % 3600) / 60), l: "Minutes" },
    { v: left % 60, l: "Seconds" },
  ];
  return (
    <div className="flex items-center justify-center gap-3">
      {parts.map((p) => (
        <div key={p.l} className="w-20 rounded-xl border border-border bg-surface-2 px-2 py-3 text-center">
          <div className="font-display text-2xl font-bold text-gold">{String(p.v).padStart(2, "0")}</div>
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{p.l}</div>
        </div>
      ))}
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="mb-3 inline-block rounded-full border border-border bg-surface px-4 py-1 text-xs font-semibold uppercase tracking-widest text-gold">
      {children}
    </span>
  );
}

function Index() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      {/* Top urgency bar */}
      <div className="bg-gradient-to-r from-primary to-gold py-2 text-center text-xs font-bold uppercase tracking-widest text-primary-foreground">
        🔥 Limited time — 90% OFF ends soon
      </div>

      {/* Hero */}
      <header className="relative overflow-hidden px-5 pb-16 pt-12">
        <div className="pointer-events-none absolute left-1/2 top-0 h-[500px] w-[900px] -translate-x-1/2 rounded-full bg-primary/15 blur-[120px]" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-10 md:grid-cols-2">
          <div className="text-center md:text-left">
            <SectionLabel>Digital PDF Bundle</SectionLabel>
            <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">
              Psychology Notes
              <span className="block text-gradient-gold">Basic to Advanced</span>
            </h1>
            <p className="mt-4 text-base text-muted-foreground">
              17+ complete topics, simplified notes and visual diagrams — everything you need to
              actually understand psychology, in one downloadable bundle.
            </p>
            <div className="mt-6 flex items-center justify-center gap-3 md:justify-start">
              <span className="text-xl text-muted-foreground line-through">₹2,499</span>
              <span className="font-display text-5xl font-extrabold text-gold">₹149</span>
              <span className="rounded-md bg-destructive px-2 py-1 text-xs font-bold text-destructive-foreground">
                90% OFF
              </span>
            </div>
            <div className="mt-6 flex justify-center md:justify-start">
              <BuyButton />
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm md:justify-start">
              <span className="rounded-lg border border-border bg-surface px-3 py-2">📄 Format: <b>PDF</b></span>
              <span className="rounded-lg border border-border bg-surface px-3 py-2">📧 Delivery: <b>Email</b></span>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              <b className="text-foreground">Note:</b> You will receive a digital copy only, not a hard copy.
            </p>
          </div>
          <img
            src={bundleImage}
            alt="Psychology study notes bundle shown on tablets and ebooks"
            width={1200}
            height={912}
            className="mx-auto w-full max-w-xl drop-shadow-2xl"
          />
        </div>
      </header>

      {/* PDF page slideshow */}
      <section className="border-t border-border bg-surface/40 px-5 py-16">
        <div className="mx-auto max-w-5xl text-center">
          <SectionLabel>Real Pages From The Bundle</SectionLabel>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">
            Take A Look Inside The PDFs
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Clean layouts, colour diagrams and exam-ready summaries on every page.
          </p>
          <div className="mt-8">
            <PdfSlideshow />
          </div>
        </div>
      </section>



      {/* Why buy now */}
      <section className="border-t border-border bg-surface/40 px-5 py-16">
        <div className="mx-auto max-w-5xl text-center">
          <SectionLabel>Psychology Bundle Offer</SectionLabel>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">Why Buy Now?</h2>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {whyNow.map((item) => (
              <div
                key={item.text}
                className="flex items-center gap-3 rounded-xl border border-border bg-surface p-4 text-left"
              >
                <span className="text-2xl">{item.icon}</span>
                <span className="text-sm font-medium">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Career benefits */}
      <section className="px-5 py-16">
        <div className="mx-auto max-w-5xl text-center">
          <SectionLabel>Psychology Career Benefits</SectionLabel>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">
            How Will This Bundle Help Your Career?
          </h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {careerBenefits.map((b) => (
              <div key={b.title} className="rounded-2xl border border-border bg-surface p-6 text-left">
                <div className="text-3xl">{b.icon}</div>
                <h3 className="mt-3 font-display text-lg font-bold">{b.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{b.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Topics */}
      <section className="border-y border-border bg-surface/40 px-5 py-16">
        <div className="mx-auto max-w-5xl text-center">
          <SectionLabel>Psychology Bundle Topics</SectionLabel>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">What Exactly Do I Get?</h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            {topics.map((t) => (
              <span
                key={t}
                className="rounded-full border border-border bg-surface px-4 py-2 text-sm font-medium"
              >
                {t}
              </span>
            ))}
          </div>
          <div className="mt-10 flex justify-center">
            <BuyButton />
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="px-5 py-16">
        <div className="mx-auto max-w-6xl text-center">
          <SectionLabel>Student Reviews</SectionLabel>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">What Students Are Saying</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {reviews.map((r) => (
              <figure key={r.name} className="rounded-2xl border border-border bg-surface p-6 text-left">
                <div className="text-gold">★★★★★</div>
                <blockquote className="mt-3 text-sm text-muted-foreground">“{r.text}”</blockquote>
                <figcaption className="mt-4 text-sm font-semibold">
                  {r.name} <span className="font-normal text-muted-foreground">· {r.city}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="border-t border-border bg-surface/40 px-5 py-16">
        <div className="mx-auto max-w-3xl">
          <div className="text-center">
            <SectionLabel>FAQ Section</SectionLabel>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Frequently Asked Questions</h2>
          </div>
          <Accordion type="single" collapsible className="mt-8">
            {faqs.map((f) => (
              <AccordionItem key={f.q} value={f.q} className="border-border">
                <AccordionTrigger className="text-left font-semibold">{f.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Final CTA */}
      <section id="buy" className="px-5 py-20 text-center">
        <div className="mx-auto max-w-2xl">
          <h2 className="font-display text-3xl font-bold sm:text-4xl">Limited Time Offer</h2>
          <p className="mt-2 text-muted-foreground">
            Price goes back to ₹2,499 when the timer hits zero.
          </p>
          <div className="mt-6">
            <Countdown />
          </div>
          <div className="mt-8 flex justify-center">
            <BuyButton label="GET THE BUNDLE — ₹149" sub="Instant PDF access by email" />
          </div>
        </div>
      </section>

      <footer className="border-t border-border px-5 py-8 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Psychology Notes. Digital product — no refunds after download.
      </footer>

      {/* Sticky mobile CTA */}
      <div className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-surface/95 p-3 backdrop-blur md:hidden">
        <Link
          to="/checkout"
          className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-gold-soft to-gold py-3 font-display font-extrabold text-accent-foreground"
        >
          BUY NOW · ₹149 <span className="text-xs font-semibold line-through opacity-70">₹2,499</span>
        </Link>
      </div>
      <div className="h-20 md:hidden" />
    </div>
  );
}
