import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getOrderByToken } from "@/lib/payments.functions";

type Search = { token?: string };

export const Route = createFileRoute("/download")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    token: typeof search.token === "string" ? search.token : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Download Your Psychology Notes Bundle" },
      {
        name: "description",
        content:
          "Payment successful. Download your Psychology Notes bundle PDFs instantly and check your email for the backup link.",
      },
      { property: "og:title", content: "Download Your Psychology Notes Bundle" },
      {
        property: "og:description",
        content: "Your purchase is confirmed — grab your PDF bundle here.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DownloadPage,
});

function DownloadPage() {
  const { token } = Route.useSearch();
  const fetchOrder = useServerFn(getOrderByToken);

  const { data, isLoading } = useQuery({
    queryKey: ["order", token],
    enabled: Boolean(token),
    queryFn: () => fetchOrder({ data: { token: token! } }),
  });

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <div className="mx-auto max-w-2xl px-5 py-16">
        <div className="rounded-2xl border border-border bg-surface p-8 text-center">
          {!token || (!isLoading && !data?.found) ? (
            <>
              <h1 className="font-display text-3xl font-extrabold">Order not found</h1>
              <p className="mt-3 text-sm text-muted-foreground">
                We couldn&apos;t find a paid order for this link. If you just paid, check
                your email for the download link or contact support.
              </p>
              <Link
                to="/"
                className="mt-6 inline-block rounded-xl border border-border px-5 py-3 text-sm font-bold"
              >
                Back to home
              </Link>
            </>
          ) : isLoading || !data?.found ? (
            <p className="text-sm text-muted-foreground">Loading your order…</p>
          ) : (
            <>
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-gold text-2xl text-accent-foreground">
                ✓
              </div>
              <h1 className="mt-5 font-display text-3xl font-extrabold">
                Payment successful, {data.name}!
              </h1>
              <p className="mt-2 text-sm text-muted-foreground">
                A confirmation with your download link is on its way to {data.email}.
              </p>

              <div className="mt-7 space-y-3">
                {data.files.map((f) => (
                  <a
                    key={f.label}
                    href={f.url}
                    target="_blank"
                    rel="noreferrer"
                    className="glow-gold block w-full rounded-xl bg-gradient-to-b from-gold-soft to-gold py-4 font-display text-base font-extrabold text-accent-foreground"
                  >
                    📥 Download {f.label}
                  </a>
                ))}
              </div>

              <div className="mt-6 rounded-xl border border-border bg-surface-2 p-4 text-left text-sm">
                <div className="flex justify-between font-bold">
                  <span>Psychology Notes Bundle (PDF)</span>
                  <span className="text-gold">₹149</span>
                </div>
                {data.addons?.map((a) => (
                  <div key={a.id} className="mt-2 flex justify-between text-muted-foreground">
                    <span className="pr-2">+ {a.title}</span>
                    <span className="text-gold">₹{a.price}</span>
                  </div>
                ))}
                <div className="mt-3 flex justify-between border-t border-border pt-3 font-display text-base font-bold">
                  <span>Paid</span>
                  <span className="text-gold">₹{data.totalRupees}</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
